package demo;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateLead {

	public static void main(String[] args) {
		RedisManager rm = new RedisManager();
		System.out.println(rm.getAllRecords("LeadIds"));
		
		
		  ChromeDriver driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  driver.get("http://leaftaps.com/opentaps/");
		  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		  driver.findElement(By.id("username")).sendKeys("DemoSalesManager");
		  driver.findElement(By.id("password")).sendKeys("crmsfa");
		  driver.findElement(By.className("decorativeSubmit")).click();
		  driver.findElement(By.linkText("CRM/SFA")).click();
		  driver.findElement(By.linkText("Leads")).click();
		  driver.findElement(By.linkText("Create Lead")).click();
		  driver.findElement(By.id("createLeadForm_companyName")).sendKeys("TestLeaf");
		  driver.findElement(By.id("createLeadForm_firstName")).sendKeys("Hari");
		  driver.findElement(By.id("createLeadForm_lastName")).sendKeys("R");
		  driver.findElement(By.name("submitButton")).click();
		  
		  String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		  String leadId = text.replaceAll("[^0-9]", ""); 
		  System.out.println(leadId);
		  driver.close();
		  
		  rm.pushToTable("LeadIds", leadId);
		  System.out.println(rm.getAllRecords("LeadIds"));
		  rm.close();
		 
	}
}
