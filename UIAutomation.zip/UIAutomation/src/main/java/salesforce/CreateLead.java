package salesforce;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class CreateLead {
	
	@Test
	public void runCreateLead() {
		
		//Open Browser and Load application
		ChromeDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		driver.get("https://login.salesforce.com/");
		
		//login steps
		driver.findElement(By.id("username")).sendKeys("hari.radhakrishnan@qeagle.com");
		driver.findElement(By.id("password")).sendKeys("Leaf@1234");
		driver.findElement(By.id("Login")).click();
		
		//click on Global actions button
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
		wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.xpath("//lightning-icon[contains(@class,'globalCreateButton')]"))));
		
	
		driver.findElement(By.xpath("//lightning-icon[contains(@class,'globalCreateButton')]")).click();
		
		driver.findElement(By.xpath("//span[text()='New Lead']")).click();
		String lastName = "Radhakrishnan";
		
		driver.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys(lastName);
		driver.findElement(By.xpath("(//span[text()='Company']/following::input)[1]")).sendKeys("Qeagle");
		
		driver.findElement(By.xpath("//span[text()='Company']/following::span[text()='Save']")).click();
		
		WebElement eleToastMessage = driver.findElement(By.xpath("//a[@title='"+lastName+"']"));
		boolean toastDisplayed = eleToastMessage.isDisplayed();
		
		//validation for the toast message
		Assert.assertTrue(toastDisplayed);
		
		

	}
	
	
	
	
	

}
